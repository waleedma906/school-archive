/* إعدادات الأرشيف.
   اتركه كما هو لتشغيل «الوضع المحلي» (البيانات في متصفحك فقط، للتجربة).
   لربط الأرشيف بقاعدة بيانات مشتركة: أنشئ مشروع Firebase وانسخ إعداداته هنا (انظر README.md). */
window.ARCHIVE_CONFIG = {
  firebase: null,
  /* مثال بعد الربط:
  firebase: {
    apiKey: "…",
    authDomain: "your-project.firebaseapp.com",
    projectId: "your-project",
    appId: "…"
  }, */
};
